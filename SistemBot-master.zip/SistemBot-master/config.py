import cProfile
import telegram

bot_token = "5195866135:AAGTOeV1FhL8RdlGoLP_5WsaEh7tPXeKt3I"

bot_user_name = "Testebotpedido_bot"

TOKEN = bot_token

bot = telegram.Bot(token=TOKEN)

nlp = {}

nlp["dic"] = '.../SistemBot/NLP'







